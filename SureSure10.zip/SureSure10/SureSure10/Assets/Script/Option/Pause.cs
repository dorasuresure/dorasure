﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class Pause : MonoBehaviour {
	
public Text Pausetext;		//ポーズ時表示する文字
private bool pause = false;	//ポーズ中かの判定
	
	// Update is called once per frame
	void Update () {
		//Tが押された時
		if (Input.GetKeyDown (KeyCode.T)) {
			//すでにポーズ中なら
			if (Time.timeScale == 0) {
				Time.timeScale = 1;
				Pausetext.enabled = false;
				pause = false;
			//そうでないなら
			} else {
				Time.timeScale = 0;
				Pausetext.enabled = true;
				pause = true;
			}
		}
        //タイム中にMを押したら
		if (pause&&Input.GetKeyDown(KeyCode.M)) {
            Time.timeScale = 1;
            //タイトルに戻る
			SceneManager.LoadScene ("title");
		}
	}
}
