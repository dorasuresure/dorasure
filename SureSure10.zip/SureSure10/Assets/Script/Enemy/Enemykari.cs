﻿using UnityEngine;
using System.Collections;

public class Enemykari : MonoBehaviour {

    public GameObject ScoreMaster;

	private int hp = 3;//敵の体力

	public int attackPoint = 65;//ダメージ量(65で1メモリ)
	public HPScript hpScript;//PlayerのHP
	//public SubHp DSub;//doragonのサブHp


	void Start () {
	}

	// Update is called once per frame
	void Update () {
		if (hp <= 0) {
			Destroy (gameObject);
			ScoreMaster.SendMessage ("ScoreUp",100);
		}
	}
	//敵の攻撃に当たったらコルーチン"Damage"に行く
	void OnTriggerEnter2D (Collider2D col){
		if (col.tag == "fire"){
			hp--;
			StartCoroutine("Damage");
			if (hp <= 0) {
				Destroy (gameObject);
				ScoreMaster.SendMessage ("ScoreUp",100);
			}
		}
		if (col.tag == "bite") {
			hp--;
			StartCoroutine("Damage");
			if (hp <= 0) {
				Destroy (gameObject);
				ScoreMaster.SendMessage ("ScoreUp",200);
			}
		}
	}

	/*void OnCollisionEnter2D (Collision2D col)
	{
		//Playerとぶつかった時
		if (col.gameObject.tag == "Player") {
			//hpScriptのHPDownメソッドを実行
			hpScript.HPDown(attackPoint);
		}
		//doragonとぶつかった時
		if (col.gameObject.tag == "Doragon") {
			//hpScriptのHPDownメソッドを実行
			DSub.subHPDown(attackPoint);
		}
	}*/

	IEnumerator Damage()
	{
		gameObject.layer = LayerMask.NameToLayer("EnemyDamage");
		yield return new WaitForSeconds(1f);
		gameObject.layer = LayerMask.NameToLayer("Enemy");
	}
}