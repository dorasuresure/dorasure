﻿using UnityEngine;
using System.Collections;

public class Fairykari : MonoBehaviour {
	
	private int hp = 3;//敵のHP

	public int attackPoint = 65;//ダメージ量(65で1メモリ)
	public HPScript hpScript;//ドラゴンのHP
	//public SubHp pSup;//プレイヤーのサブHP

	public GameObject ScoreMaster;
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		if (hp <= 0) {
			Destroy (gameObject);
			ScoreMaster.SendMessage ("ScoreUp",100);
		}
	}

	//敵の攻撃に当たったらコルーチン"Damage"に行く
	void OnTriggerEnter2D (Collider2D col){
		if (col.tag == "Slash"){
			hp--;
			StartCoroutine("Damage");
		}
		if (col.tag == "mahou") {
			Destroy (gameObject);
			ScoreMaster.SendMessage ("ScoreUp",200);
		}
	}

	/*void OnCollisionEnter2D (Collision2D col)
	{
		//Doragonとぶつかった時
		if (col.gameObject.tag == "Doragon") {
			//hpScriptのHPDownメソッドを実行
			hpScript.HPDown(attackPoint);
		}
		//Playerとぶつかった時
		if (col.gameObject.tag == "Player") {
			//hpScriptのHPDownメソッドを実行
			pSup.subHPDown(attackPoint);
		}

	}*/
	IEnumerator Damage()
	{
		gameObject.layer = LayerMask.NameToLayer("FairyDamage");
		yield return new WaitForSeconds(1f);
		gameObject.layer = LayerMask.NameToLayer("Fairy");
	}
}
