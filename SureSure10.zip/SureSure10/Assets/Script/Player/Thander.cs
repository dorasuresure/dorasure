﻿using UnityEngine;
using System.Collections;

public class Thander : MonoBehaviour {
	// Update is called once per frame
	void Update () {
        Destroy(gameObject, 1);
	}
}
