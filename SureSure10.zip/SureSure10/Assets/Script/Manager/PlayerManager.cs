﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//  プレイヤー管理クラス
public class PlayerManager {

	//  プレイヤーデータのリスト
	List<Player> m_player_list = new List<Player>();

	//  プレイヤーデータ追加
	public void AddPlayer(Player _p)
	{
		m_player_list.Add(_p);
	}

	//  プレイヤーデータ削除
	public void DeletePlayer(string _name)
	{
		foreach(Player g in m_player_list)
		{
			if(g.name == _name)
			{
				m_player_list.Remove(g);
			}
		}
	}

	//  一時停止関数
	public void Pause()
	{
		foreach(Player g in m_player_list)
		{
			//  ここで個別にポーズをしてあげる
			//g.Pause();
		}
	}
}
