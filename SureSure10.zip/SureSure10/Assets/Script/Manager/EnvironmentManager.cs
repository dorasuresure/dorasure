﻿using UnityEngine;
using System.Collections;

//  環境クラス
public class EnvironmentManager {

	//  staticで定義されているので、ゲーム中常に存在し、１つしかない
	static EnvironmentManager m_instance = null;

	//  ここは普通に定義されているそれぞれの管理クラス
	PlayerManager m_player_manager = new PlayerManager();
	GameObject m_timer_manager = new GameObject();

	//  インスタンス化とアクセスを両立してる。
	public static EnvironmentManager Instance
	{
		get
		{
			if(m_instance == null)
			{
				m_instance = new EnvironmentManager();
			}
			return m_instance;
		}
	}

	//  プレイヤーマネージャー取得
	public PlayerManager PlayerManager
	{
		get { return m_player_manager; }
	}

	//  一時停止処理(つくるならこんな感じのサンプル)
	public void Pause()
	{
		m_player_manager.Pause();
		//m_timer_manager.Pause();

	}
}
