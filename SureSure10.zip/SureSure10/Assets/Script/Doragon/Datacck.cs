using UnityEngine;
using System.Collections;

public class Datacck : MonoBehaviour {

	private GameObject Doragon;      //ドラゴン取得用
	public float atacckspeed = 10f; //攻撃のスピード 
	public float destoroytime = 1f; //消える時間
	// Use this for initialization
	void Start () {
		Doragon = GameObject.FindWithTag("Doragon");
		//rigidbody2Dコンポーネントを取得
		Rigidbody2D rigidbody2D = GetComponent<Rigidbody2D>();
        //atacckspeedの数値だけ進む
		rigidbody2D.velocity = new Vector2 (atacckspeed * Doragon.transform.localScale.x, rigidbody2D.velocity.y);
        //ドラゴンの向いてる向きをとる
		Vector2 temp = transform.localScale;
		temp.x = Doragon.transform.localScale.x * -1;
		transform.localScale = temp;
		//1秒後に消滅
		Destroy(gameObject, destoroytime);
	}
	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.gameObject.tag == "Enemy") {
			Destroy(gameObject);
		}
		if (col.gameObject.tag == "Block") {
			Destroy(gameObject);
		}
	}
}
