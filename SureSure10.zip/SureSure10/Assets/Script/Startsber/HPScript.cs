using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class HPScript : MonoBehaviour
{

    RectTransform rt;

    //?J?n
    public GameObject player;   //?v???C???[
    private bool gameOver = false;  //?Q?[???I?[?o?[????
    public GameObject GameOverPanel;
    //?I??

    // Use this for initialization
    void Start()
    {
        rt = GetComponent<RectTransform>();
    }

    // Update is called once per frame
    //?J?n
    void Update()
    {
        if (rt.sizeDelta.x <= 0)
        {
            GameOver();
        }
        if (gameOver)
        {
            
			GameOverPanel.SetActive(true);
        }
		//Xキーでタイトルに戻る
		if (Input.GetKeyDown(KeyCode.X)&& rt.sizeDelta.x <= 0)
		{
			SceneManager.LoadScene("title");
		}
    }

    public void HPDown(int ap)
    {
        rt.sizeDelta -= new Vector2(ap, 0);
    }
	public void HPUp (int hp)
	{
		rt.sizeDelta += new Vector2 (hp,0);
		if (rt.sizeDelta.x > 331f) {
			rt.sizeDelta = new Vector2 (331f, 62f);
		}
	}


    public void GameOver()
    {
        Destroy(player);
        gameOver = true;
        Debug.Log("gameover");
    }
}
