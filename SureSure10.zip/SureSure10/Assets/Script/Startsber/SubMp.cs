using UnityEngine;
using System.Collections;

public class SubMp : MonoBehaviour {

	RectTransform rt;
	public MpScript MpScript;

	private int Stock = 33;
	
	void Start () {
		rt = GetComponent<RectTransform>();
	}
	public void Mpgain(int mpg){
		//RectTransformのサイズを取得し、プラスにする
		rt.sizeDelta += new Vector2 (mpg,0);
		//最大値を越えたら消えて、右に移動する
		if(rt.sizeDelta.y > 51f){
			rt.sizeDelta = new Vector2 (0.01f,29f);
			MpScript.MpStock(Stock);
		}
	}
}
