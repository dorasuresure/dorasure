﻿using UnityEngine;
using System.Collections;

public class SubHp : MonoBehaviour {

	RectTransform rt;

	public HPScript Hpscript;

	void Start () {
		rt = GetComponent<RectTransform>();
	}
	public void subHPDown(int ap)
	{
		rt.sizeDelta -= new Vector2 (ap, 0);
		//0になったら全快してHPを減らす
		if (rt.sizeDelta.x <= 0.1f) {
			rt.sizeDelta = new Vector2 (260f, 29f);
			Hpscript.HPDown (66);

		}
	}
}
