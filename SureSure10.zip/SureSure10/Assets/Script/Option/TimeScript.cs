﻿using UnityEngine;
using System.Collections;

public class TimeScript : MonoBehaviour {
    //タイム用
	public static float time;	//制限時間
	public bool TimeKeep = true;	//クリアした時に時間を止めるよう

    // Use this for initialization
    void Start () {
		time = 100;
    }

    // Update is called once per frame
    void Update () {
		if (TimeKeep) {
			time -= Time.deltaTime;
		}
        if (time < 0) time = 0;
	}
}
