﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Score : MonoBehaviour {
	//スコア用
	public Text Scoretext;           //スコア表示用
	public Text RizaltScore;         //クリア時表示用スコア
	public Text TimeBonus;  		 //タイムボーナス表示用
	public Text TotalScoreText;        //トータル表示用スコア
	public Text HighScoreText;       //1位テキスト
	public GameClear gameclea;		//GameClear保持用
	private int TotalScore;				//合計スコア保持用
	private int score = 0;            //スコア入れる変数
	private int HighScore;            //1位スコア
	private string key = "Highscore";//1位保存キー

	// Use this for initialization
	void Start () {
		Scoretext.text = "Score:" + score.ToString();
		RizaltScore.text = "Score" + score.ToString();
		//TimeBonus.text = "TimeBounus" + ((int)TimeScript.time * 10);
		TotalScoreText.text = "YourScore" + score.ToString();
		HighScore = PlayerPrefs.GetInt(key, 1500);
		HighScoreText.text = "HighScore:" + HighScore.ToString();
	}
	public void ScoreUp(int point)
	{
		score += point;
		Scoretext.text = "Score:" + score.ToString();
		RizaltScore.text = "Score" + score.ToString();
	}
	void Update(){
		TimeBonus.text = "TimeBounus" + ((int)TimeScript.time * 10);
		TotalScore = ((int)TimeScript.time * 10) + score;
		TotalScoreText.text = "YourScore" + TotalScore.ToString();
		//ハイスコア初期化用(ハイスコアを初期化したいときにコメントを外すこと)
		//PlayerPrefs.SetInt(key, 1500);
		if(gameclea.Clear){
			if (TotalScore > HighScore) { 
				//ハイスコア更新
				HighScore = TotalScore;
				//ハイスコア保存
				PlayerPrefs.SetInt(key, HighScore);
				//ハイスコア表示
				HighScoreText.text = "HighScore:" + HighScore.ToString();
			}
		}
	}
}
