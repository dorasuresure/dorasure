﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameClear : MonoBehaviour {
    public GameObject Panel;      //暗転用パネル取得
    public Text ClearText;        //GameClea表示用
    public Text Score;            //スコア表示用
    public Text TimeCount;        //残り時間表示用
    public Text RizaltScore;      //クリア時に出すスコア
    public Text Timebonus;        //クリア時に出すボーナスの表示用
    public Text SumScore;         //トータルスコア表示用
    public Text HightScore;       //ハイスコア表示用
    public TimeScript timescript; //タイムスクリプト取得用
    public Player Player;         //プレイヤー取得
    public doragon doragon;       //ドラゴン取得
	public bool Clear = false;    //クリア判定

    private int count = 0;        //ボタンを押した回数
    private new Rigidbody2D rigidbody2D;//箱に触るために必要(ボスを倒した判定には不要)

	void Start(){
        //ここもボスを倒した判定には不要
		rigidbody2D = GetComponent<Rigidbody2D>();
	}
	void OnCollisionEnter2D(Collision2D col)
	{
		//人間が触れたらクリア
		if (col.gameObject.tag == "Player") {
			//コルーチンを呼び出す
			StartCoroutine(gameClea());
		}

		//ドラゴンが触れたらクリア
		if (col.gameObject.tag == "Doragon") {
			//コルーチンを呼び出す
			StartCoroutine(gameClea());
		}
	}
	private IEnumerator gameClea() {
        //ドラゴンの動きを止める
		doragon.DPlaying = false;
        //プレイヤーの動きを止める
		Player.Playing = false;
        //タイマーを止める
		timescript.TimeKeep = false;
        //右上のタイマーとスコアを非表示
        Score.enabled = false;
        TimeCount.enabled = false;
		//画面暗転
		Panel.SetActive(true);
		//クリア文字を出す
		ClearText.enabled = true;
		//2秒待つ
		yield return new WaitForSeconds(2f);
        Clear = true;
    }
    void Update() {
        if (Clear) {
            if (Input.GetKeyDown(KeyCode.X)) {
                if (count == 0)
                {
                    ClearText.enabled = false;
                    RizaltScore.enabled = true;
                    Timebonus.enabled = true;
                }
                if (count == 1) {
                    SumScore.enabled = true;
                }
                if(count == 2)
                {
                    HightScore.enabled = true;
                }
                if (count == 3)
                {
                    SceneManager.LoadScene("title");
                }
                count++;
            }
        }
    }
}
