﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TimeMaster : MonoBehaviour {
	public Text TimeText;	//表示する時間
	public Player Player;	//プレイヤー取得
	public doragon doragon;	//ドラゴン取得
	public GameObject Panel;//暗転用のパネル
	public Text GameOver;	//GameOver用テキスト

	// Use this for initialization
	void Start () {
		//時間をint型で表示
		TimeText.text = "Time:" + ((int)TimeScript.time).ToString();
	}

	// Update is called once per frame
	void Update () {
		TimeText.text = "Time:" + ((int)TimeScript.time).ToString ();
		if(TimeScript.time <= 0){
			StartCoroutine("TimeUp");
		}
	}
	IEnumerator TimeUp(){
		Panel.SetActive(true);
		GameOver.enabled = true;
		doragon.DPlaying = false;
		Player.Playing = false;
		yield return new WaitForSeconds(2.0f);
		SceneManager.LoadScene("title");
	}
}
