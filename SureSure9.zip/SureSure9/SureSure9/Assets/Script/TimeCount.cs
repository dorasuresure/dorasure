﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TimeCount : MonoBehaviour {
    private float time = 6;         //制限時間
    public Text Gameover;           //時間切れ
    public PlayerScript PlayreScript;       
    public DoragonScript DoragontScript;

	// Use this for initialization
	void Start () {
        //初期値200を表示
        //float型からint型へCastし、String型に変換して表示
        GetComponent<Text>().text = ((int)time).ToString();
	}
	
	// Update is called once per frame
	void Update () {
	    //1秒ずつ減らす
        time -= Time.deltaTime;
        if (time < 0) {
            StartCoroutine("TimeUp");
        }
        //マイナスにしない
        if (time < 0) time = 0;
        GetComponent<Text>().text = ((int)time).ToString();
	}
    IEnumerator TimeUp() {
    }
}
