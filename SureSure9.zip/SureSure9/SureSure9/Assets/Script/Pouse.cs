﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Pouse : MonoBehaviour {
public Text PoseText;
public Text PoseText2;
private bool Pose = false;
	// Use this for initialization
	void Start () {
	    
	}
	
	// Update is called once per frame
	void Update () {
	    if (Input.GetKeyDown(KeyCode.T)){
            if (Time.timeScale == 0){
                Time.timeScale = 1;
                PoseText.enabled = false;
                PoseText2.enabled = false;
                Pose = true;
            }
            else {
                Time.timeScale = 0;
                PoseText.enabled = true;
                PoseText2.enabled = true;
                Pose = true;
            }
        }
        if (Input.GetKeyDown(KeyCode.M)&&Pose)
        {
            SceneManager.LoadScene("title");
            Time.timeScale = 1;
        }
	}
}
