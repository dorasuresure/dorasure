﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TimeScript : MonoBehaviour {
	private float time = 200;
    public Player Player;
    public doragon doragon;
    public Text GameOver;

	// Use this for initialization
	void Start () {
		GetComponent<Text>().text = "Time:" +((int)time).ToString();
	}
	
	// Update is called once per frame
	void Update () {
        time -= Time.deltaTime;
        if(time < 0){
            StartCoroutine("TimeUp");
        }

        if (time < 0) time = 0;
        GetComponent<Text>().text = "Time:" + ((int)time).ToString();
	}
    IEnumerator TimeUp(){
        GameOver.enabled = true;
        doragon.DPling = false;
        Player.Plaing = false;
        yield return new WaitForSeconds(2.0f);
        SceneManager.LoadScene("title");

    }
}
