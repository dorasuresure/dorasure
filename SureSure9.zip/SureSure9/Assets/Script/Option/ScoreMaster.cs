﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ScoreMaster : MonoBehaviour {
	//public GameObject Fairy;
	//public GameObject Enemy;
	public Text Scoretext;
	private int score = 0;

	void Start(){
		Scoretext.text = "Score:" + score.ToString(); 
	}
	void Update () {
	}
	public void ScoreUp(int point){
		score += point;
		Scoretext.text = "Score:" + score.ToString(); 
	}
}
