﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class Pose : MonoBehaviour {
	
public Text posetext;		//ポーズ時表示する文字
private bool pose = false;	//ポーズ中かの判定

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		//Tが押された時
		if (Input.GetKeyDown (KeyCode.T)) {
			//すでにポーズ中なら
			if (Time.timeScale == 0) {
				Time.timeScale = 1;
				posetext.enabled = false;
				pose = false;
			//そうでないなら
			} else {
				Time.timeScale = 0;
				posetext.enabled = true;
				pose = true;
			}
		}
		if (pose&&Input.GetKeyDown(KeyCode.M)) {
            Time.timeScale = 1;
			SceneManager.LoadScene ("title");
		}
	}
}
