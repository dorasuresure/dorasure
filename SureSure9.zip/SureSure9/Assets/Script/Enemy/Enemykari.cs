﻿using UnityEngine;
using System.Collections;

public class Enemykari : MonoBehaviour {

	private int hp = 3;
	public GameObject ScoreMaster;
	void Start () {
	}

	// Update is called once per frame
	void Update () {
		if (hp <= 0) {
			Destroy (gameObject);
			ScoreMaster.SendMessage ("ScoreUp",100);
		}
	}
	//敵の攻撃に当たったらコルーチン"Damage"に行く
	void OnTriggerEnter2D (Collider2D col){
		if (col.tag == "fire"){
			hp--;
			StartCoroutine("Damage");
			if (hp <= 0) {
				Destroy (gameObject);
				ScoreMaster.SendMessage ("ScoreUp",100);
			}
		}
		if (col.tag == "bite") {
			hp--;
			StartCoroutine("Damage");
			if (hp <= 0) {
				Destroy (gameObject);
				ScoreMaster.SendMessage ("ScoreUp",200);
			}
		}
	}
	IEnumerator Damage()
	{
		gameObject.layer = LayerMask.NameToLayer("EnemyDamage");
		yield return new WaitForSeconds(1f);
		gameObject.layer = LayerMask.NameToLayer("Enemy");
	}
}